#!/bin/bash
# KREW Skills Install Script
# Run from Claude Code: bash install-skills.sh
# Copies 9 new skills from outputs/skills/ to /mnt/skills/user/
# Date: 18.06.2026

SKILLS_SOURCE="$HOME/Downloads/skills"  # Adjust to where you extracted the outputs
SKILLS_TARGET="/mnt/skills/user"        # Or wherever your user skills directory is

echo "KREW Skills Installer · 18.06.2026"
echo "===================================="

SKILLS=(
  "krew-csuite-review"
  "krew-task-card"
  "krew-atopp"
  "krew-agent-onboard"
  "krew-qms-deviation"
  "krew-email-draft-no"
  "krew-decision-log"
  "krew-business-case"
  "krew-hardware-review"
)

for skill in "${SKILLS[@]}"; do
  src="$SKILLS_SOURCE/$skill/SKILL.md"
  dst="$SKILLS_TARGET/$skill"
  
  if [ -f "$src" ]; then
    mkdir -p "$dst"
    cp "$src" "$dst/SKILL.md"
    echo "✓ $skill"
  else
    echo "✗ $skill — not found at $src"
  fi
done

echo ""
echo "Done. Verify with: ls $SKILLS_TARGET"
