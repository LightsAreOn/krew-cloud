---
name: krew-agent-onboard
description: "Run this checklist whenever a new KREW agent is being created, named, or formally registered. Triggers include: 'new agent', 'add [name] to the roster', 'register [name]', 'onboard [name]', or any session where an agent is given an ID, role, or model assignment. Covers all five required steps: agent_catalogue, QMS document, ISCO-08 code, model tier, and Slack announcement."
---

# KREW Agent Onboarding Skill

## Overview

Every KREW agent must be registered across five systems before they are considered active. Partial registration is a QMS deviation (DEV severity 2). Run all five steps in sequence.

## Step 1 — Assign agent ID and confirm slot

Current roster as of 18.06.2026:
- KREW-A001 Michael (CEO) through KREW-A017 Jessica (CRCO)
- Next available: KREW-A018

Format: `KREW-A0XX` — always four-digit zero-padded.

Before assigning, confirm the slot is empty:
```sql
SELECT agent_id, function_name, status FROM agent_catalogue ORDER BY agent_id;
```

## Step 2 — Register in agent_catalogue

```sql
INSERT INTO agent_catalogue (
  agent_id,        -- 'KREW-A018'
  agent_code,      -- 'A018'
  function_name,   -- First name only: 'Marcus'
  full_title,      -- Full function title: 'Commercial Due Diligence Agent'
  type,            -- 'catalogue' | 'night_owl' | 'catalogue_pending'
  model,           -- See model tier table below
  status,          -- 'active' | 'pending' | 'onboarding'
  isco_code,       -- 4-digit ISCO-08 code as text: '2431'
  isco_title,      -- ISCO-08 unit title: 'Advertising and marketing professionals'
  isco_major,      -- ISCO major group label
  workspace        -- 'krew' | 'sagaworx' | 'spotlight'
)
```

### Model tier assignment

| Agent tier | Model | Max thinking |
|-----------|-------|--------------|
| CEO + CLO | claude-opus-4-8 | 12K |
| CTO | claude-sonnet-4-6 | 10K |
| CPO + Coder | claude-sonnet-4-6 | 8K |
| CMO + CRCO | claude-sonnet-4-6 | 6K |
| CFO | claude-sonnet-4-6 | 5K |
| Night Owls (Briefer/Ops/CM/PA) | claude-haiku-4-5 | standard |
| Night Owls (specialist) | claude-sonnet-4-6 | standard |

Assign the lowest tier that fits the role. Do not over-provision.

### Type definitions

- **catalogue**: Available for clients to hire. Appears in agent catalogue on krew.cloud.
- **night_owl**: Internal infrastructure. Not client-facing. Operates autonomously overnight or on triggers.
- **catalogue_pending**: In development. Not yet in client catalogue.

## Step 3 — ISCO-08 lookup

Always assign an ISCO-08 occupation code. Look up in the `isco08` table:

```sql
SELECT code, title FROM isco08
WHERE title ILIKE '%[relevant keyword]%'
ORDER BY code;
```

Key rule: **CLO (Louis) must use ISCO 2611 (Lawyers) — this is a protected title in Norway. Internal use only. Never shown to clients.**

If no exact match exists, assign the closest sub-major group (3-digit code) and note the limitation.

## Step 4 — Register in QMS documents

```sql
-- Create document record
INSERT INTO qms_documents (series, num, title, revision, status, owner, approver, category, notes, approved_by, approved_at)
VALUES (
  'KREW-HR',
  [next_num],  -- SELECT MAX(num)+1 FROM qms_documents WHERE series='KREW-HR'
  'Agent Profile · [Function Name] · [Agent ID]',
  '1.0',
  'APPROVED',
  'Chairman · KREW-H001',
  'Chairman · KREW-H001',
  'agent_profile',
  '[Brief description: role, scope, model, ISCO code]',
  'Chairman · KREW-H001',
  NOW()
);
```

Then upload the L3 definition document to `qms_document_files`. If the L3 document is not yet written, set a PENDING_UPLOAD placeholder and create an AO for the responsible agent (ALF usually) to write and upload it.

## Step 5 — Slack announcement

Post to #proj-krew:

```
*New agent onboarded · [AGENT-ID]*
*[Function name] · [Full title]*

Role: [2 sentences on what this agent does]
Model: [model string]
ISCO: [code] — [title]
Type: [Catalogue / Night Owl]
QMS: KREW-HR-[num] registered

Welcome to the krew, [first name].
— Mitch · KREW Manager
```

## Post-onboarding checks

- [ ] agent_catalogue row confirmed with SELECT
- [ ] isco_code and isco_title populated (not null)
- [ ] qms_documents row created (KREW-HR-XXX)
- [ ] qms_document_files has content or PENDING_UPLOAD placeholder
- [ ] Slack announcement posted
- [ ] If Night Owl: L3 prompt and trigger mechanism defined (AO for CTO/ALF if not yet done)

## Common deviations to avoid

- DEV: Agent referenced in tasks or decisions before being registered in agent_catalogue
- DEV: agent_catalogue row created without ISCO code
- DEV: CLO ISCO 2611 shown in client-facing materials
- DEV: New agent not announced in Slack before being given tasks
