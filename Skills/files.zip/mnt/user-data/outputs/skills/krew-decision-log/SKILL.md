---
name: krew-decision-log
description: "Apply the confirm-and-log protocol whenever Andy confirms a decision, says 'yes', 'go', 'approved', 'ok', 'confirmed', 'lock it', 'do it', or any affirmative that closes a question that was under discussion. BEFORE executing, surface 'Please confirm that I log: [X]'. After confirmation, write to Supabase FIRST, then execute. Session memory is never sufficient record-keeping."
---

# KREW Decision Log Skill

## The core rule (KREW-GOV-003)

**Every Chairman-confirmed decision must be persisted to Supabase immediately.**
Session memory is not a record. If it's not in the database, it didn't happen.

## What counts as a decision

A decision is any Chairman-confirmed:
- Strategic direction (product, commercial, architecture)
- Agent or staff appointment or change
- Financial commitment or spend authorisation
- Process rule ratification (KREW-OPS-XXX, KREW-GOV-XXX)
- Governance change (layer model, authority matrix, approval chain)
- Product decision (scope, feature, launch date, pricing)
- Technology decision (stack, vendor, model assignment)
- Partnership or client relationship commitment

Not a decision: style preferences, minor wording choices, requests for information, task assignments (those go in `agent_tasks`).

## The protocol — three steps

### Step 1 — Surface before executing

When Andy says something that looks like a confirmation ("yes", "do it", "go", "ok", "confirmed"), surface:

```
Please confirm that I log:
[One-sentence summary of exactly what is being decided]

Writing to: [table — see routing below]
```

Wait for Andy to say yes before writing. If he adjusts the wording, use his version.

Exception: If Andy says "log it" or "add to QMS" explicitly, surface the summary immediately and log without a second confirmation prompt.

### Step 2 — Write to Supabase FIRST

Log before executing any downstream action. If the write fails, do not proceed.

### Step 3 — Confirm and execute

```
Logged: [reference/kind] ✓
Executing: [what happens next]
```

## Table routing

| Decision type | Table | kind field |
|--------------|-------|-----------|
| Governance, process rule, authority | `qms_audit_log` | `governance_decision` |
| Product or commercial decision | `qms_audit_log` | `product_decision` |
| C-suite formal vote (6/6 format) | `decisions` | — |
| Agent appointment or change | `qms_audit_log` | `agent_appointment` |
| Schema or infrastructure change | `qms_audit_log` | `schema_change` |
| Financial commitment | `qms_audit_log` | `financial_commitment` |
| Technology/vendor decision | `qms_audit_log` | `technology_decision` |

### qms_audit_log format

```sql
INSERT INTO qms_audit_log (kind, entry, created_by)
VALUES (
  '[kind]',
  '[DECISION TYPE] · [Short reference] · [Full decision statement in 1-3 sentences. Include rationale if discussed.]',
  'Chairman · [date]'
);
```

### decisions table format (for formal C-suite votes)

```sql
INSERT INTO decisions (
  ref,          -- 'KREW-DEC-XXX' — check max ref first
  title,        -- Short decision title
  description,  -- Full decision statement
  decided_by,   -- 'Chairman' or 'C-suite · 6/6'
  decided_at,   -- NOW()
  vote_result   -- '6/6 YES' or 'UNANIMOUS' or '4/6 YES'
)
```

## Multiple decisions in one message

Andy frequently confirms multiple decisions in a single short message. Capture all of them. Surface a combined confirm prompt:

```
Please confirm that I log these decisions:
1. [Decision A]
2. [Decision B]
3. [Decision C]

Writing to: qms_audit_log (governance_decision × 3)
```

## Common failure modes (deviations to avoid)

- **DEV-class**: Proceeding with execution before logging — always write first
- **DEV-class**: Using session memory as the record ("I'll note that for later") — write now or it's lost
- **DEV-class**: Logging to the wrong table (e.g., a financial commitment in qms_audit_log as 'governance_decision')
- **DEV-class**: Embedding the decision in a longer entry where it can't be searched — keep the `entry` field queryable

## What does NOT need logging

- Andy asking a question (not a decision until answered and confirmed)
- Preliminary discussion of options
- Agent recommendations (Recommended vs final decision)
- Style and wording preferences

## Audit log hygiene

The `qms_audit_log` is the primary governance record. Keep entries:
- **Searchable**: start with a clear tag (DECISION / DEVIATION CLOSED / AGENT APPOINTED / etc.)
- **Standalone**: the entry should be understandable without context from the session
- **Concise**: 1-3 sentences. Not a transcript of the discussion.
- **Dated**: always include date in `created_by` field
