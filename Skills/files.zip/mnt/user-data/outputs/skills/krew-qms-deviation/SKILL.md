---
name: krew-qms-deviation
description: "File a QMS deviation whenever Andy says 'log a deviation', 'this is a DEV', 'that's a deviation', 'file a deviation for [X]', or whenever a process failure, near-miss, or non-conformance is identified — even if Andy doesn't explicitly ask. Deviations protect the system. When in doubt, file one."
---

# KREW QMS Deviation Skill

## When to file — proactively

File a deviation without being asked when:
- A Chairman-confirmed decision was not persisted to Supabase
- An agent completed a task without uploading output (ATOPP violation)
- A document was published without authorship disclosure
- A process rule (KREW-OPS-XXX) was violated
- A schema was misunderstood and data was routed to the wrong table
- A confidential file was nearly committed to a public repository
- Any near-miss that could have caused a governance, legal, or data integrity failure

## Severity levels

| Severity | Definition | Examples |
|----------|-----------|---------|
| 1 — Minor | Process drift, low impact, easily corrected | Missing Slack post, formatting error in output |
| 2 — Moderate | Process failure, no client impact, correction needed | Agent registered without QMS document, task completed without ATOPP |
| 3 — Significant | Process failure with potential client or data impact | Decision not persisted, schema misrouting, near-miss on confidential data |
| 4 — Critical | Actual breach, client impact, regulatory risk | Confidential data exposed, contract error, GDPR violation |

## Supabase write (ccgsewlomcyikqpigofi)

Use `qms_deviations` table. `dev_id` is auto-generated — NEVER insert it manually.

```sql
INSERT INTO qms_deviations (
  num,          -- Subquery: (SELECT COALESCE(MAX(num),0)+1 FROM qms_deviations WHERE year = EXTRACT(year FROM NOW()))
  title,        -- Short, specific. Not "Process error" — use "Agent task completed without ATOPP output upload"
  description,  -- What happened, when, discovered how
  severity,     -- 1 | 2 | 3 | 4
  status,       -- 'open' | 'closed'
  root_cause,   -- WHY it happened (not what — that's description)
  corrective_action, -- What is being done to fix it
  preventive_action, -- What prevents recurrence
  owner,        -- Agent code or 'Chairman'
  reported_by,  -- 'Chairman · [date]' or Claude session reference
  raised_at     -- NOW()
)
VALUES (
  (SELECT COALESCE(MAX(num),0)+1 FROM qms_deviations WHERE year = EXTRACT(year FROM NOW())),
  '[title]',
  '[description]',
  [severity],
  'open',
  '[root_cause]',
  '[corrective_action]',
  '[preventive_action]',
  '[owner]',
  'Chairman · [date]',
  NOW()
);
```

## Reference format

DEV-[YEAR]-[num] — e.g., DEV-2026-014

Always refer to deviations by this reference in all subsequent communication and audit log entries.

## Root cause analysis — five whys minimum

Do not write "error in process" as root cause. Dig:
1. What failed? (the event)
2. Why did it happen? (the immediate cause)
3. Why was that cause allowed to exist? (the systemic gap)
4. What rule or check should have caught it?
5. Why wasn't that rule in place or followed?

The answer to question 5 is usually the real root cause.

## Closing a deviation

A deviation is only closed when:
- The corrective action has been completed and verified
- The preventive action is documented in a KREW-OPS or SKILL
- The audit log confirms completion

```sql
UPDATE qms_deviations
SET status = 'closed', closed_at = NOW(), closed_by = '[agent or Chairman]',
    closure_note = '[what was done and verified]'
WHERE dev_id = 'DEV-2026-XXX';
```

Also log to qms_audit_log:
```sql
INSERT INTO qms_audit_log (kind, entry, created_by)
VALUES ('deviation_closed', 'DEV-2026-XXX CLOSED · [brief summary of corrective action]', '[closer]');
```

## Existing deviation log (current open items as of 18.06.2026)

- DEV-2026-014 (sev 3): Claude operating with incomplete Supabase schema — OPEN
- Others may exist — always check before filing to avoid duplicates:

```sql
SELECT dev_id, title, severity, status FROM qms_deviations ORDER BY raised_at DESC LIMIT 20;
```

## What NOT to file as a deviation

- Minor wording preferences or stylistic corrections — not deviations
- Features Andy wants to add — not deviations, they're task cards
- Bugs in code — file as WO task cards, only elevate to deviation if the bug caused a process failure
