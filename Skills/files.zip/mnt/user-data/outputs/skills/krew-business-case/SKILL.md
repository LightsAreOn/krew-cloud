---
name: krew-business-case
description: "Build a structured business case or plan whenever Andy says 'make a business plan for', 'business case for', 'board deck for', 'make a plan similar to [X] but for [Y]', or 'pitch for [venture]'. Follows the Spitsbergen Invest AS standard format: C-suite review first, then ten-section plan, then financial model. Always produced as HTML. Always ends with a Bruce (BizDev) F1-F5 review."
---

# KREW Business Case Skill

## When to trigger

- "Business plan for [X]"
- "Board document for [X]"
- "Make a pitch / deck / plan"
- "Build the case for [investment / product / venture]"
- "Same as [BOARD-XXX] but for [Y]"

## Pre-work: C-suite input

Before writing, convene a mini C-suite review (see `krew-csuite-review` skill). Minimum three agents: Michael (CEO, strategy), Bud (CFO, financial model), Bruce (BizDev, market). Include Louis (CLO) if the venture involves contracts, partnerships, or new entities.

State up front: "This is a planning document, not a final commitment. Chairman decides after reading."

## Document structure — ten sections

Every business case follows this structure regardless of topic:

```
01 · Executive Summary
    One page. The whole story in 200 words. Chairman should be able to decide from this alone.

02 · The Opportunity
    Market size. The problem. Why now. Why us.

03 · The Venture / Product / Initiative
    What it is. What it does. How it's different.
    For KREW: specify which agents are involved, what the 30+300 model means for this context.

04 · Service / Product Architecture
    How it works. Key capabilities. Delivery model.

05 · Partnership & Ownership (if applicable)
    Entity structure. Equity split. Governance. Spitsbergen Invest AS maintains control.

06 · Operating Model
    Headcount (human + agent). Self-cost (NOK 3,500/hour). Infrastructure cost.
    For KREW: agent cost vs human cost comparison.

07 · Financial Projections (3 years)
    Revenue: Year 1 / Year 2 / Year 3
    EBITDA: Year 1 / Year 2 / Year 3
    Monthly burn: [amount]
    Break-even: [month]
    Key assumptions listed explicitly.

08 · Go-to-Market
    Beachhead customer / segment. Sales motion. Channel. First 90-day milestones.
    For Norwegian market: Atea, BDO, Patrizia, family offices as reference anchors.

09 · Governance & Commitments
    Decision rights table. What requires Chairman approval. Reserved matters.
    Document authorship: PRODUCED BY AI · APPROVED BY [human].

10 · Risk Register
    Top 5 risks. Likelihood / impact / mitigation per risk.
    Bruce's F1–F5 framework applied.
```

## Financial model conventions

- Currency: NOK unless explicitly international
- Andy's self-cost: NOK 3,500/hour (use this for build-vs-buy decisions)
- Agent cost benchmark: Haiku ~NOK 0.20/hour, Sonnet ~NOK 2/hour, Opus ~NOK 15/hour vs human NOK 800–3,500/hour
- EBITDA margin targets: SaaS 70%+, consulting 60%+, platform 50%+
- Year 1 should be achievable with current team (≤2 humans + available agents)

## Bruce's F1–F5 review (always at the end)

Bruce (Business Development Agent, KREW-A008) reviews every business case with five findings:

```
BRUCE · BizDev Review · KREW-A008

F1 [RESOLVED / OPEN]: [Finding — risk or gap in the plan]
F2 [RESOLVED / OPEN]: [Finding]
F3 [RESOLVED / OPEN]: [Finding]
F4 [RESOLVED / OPEN]: [Finding]
F5 [RESOLVED / OPEN]: [Finding]

VERDICT: APPROVE / APPROVE WITH CONDITIONS / REJECT
CONDITIONS (if applicable): [What must be true before proceeding]

— Bruce · Business Development Agent · KREW
```

F1 should be the most critical blocking issue. F2–F5 in descending importance.

## Document metadata

Every business case produced gets a KREW-BOARD-XXX reference:

```sql
INSERT INTO qms_documents (series, num, title, status, owner, category, notes, revision, approved_by)
VALUES ('KREW-BOARD', [next_num], '[Title]', 'DRAFT', 'Chairman', 'business_case', '[brief]', '1.0', 'pending');
```

Status starts DRAFT. Chairman reads and confirms → APPROVED. Never APPROVED without Chairman review.

## Confidentiality

Business cases are CONFIDENTIAL by default. Do not include:
- Ownership percentages or equity splits in any client-facing output
- Revenue projections in any outward-facing material
- Agent pet names (Michael Scott, Bud Fox, etc.) — function titles only
- Specific partner names before NDAs are signed
