---
name: krew-hardware-review
description: "Run a structured technical architecture review whenever Andy asks about hardware purchases, server decisions, networking equipment, datacenter build, or any infrastructure question where cost/risk/feasibility tradeoffs exist. Triggers include: 'should we use X or Y', 'is this the right choice for the rack', 'CTO on this hardware', 'what do we need for GEN4', or any question about SAGA.WORX infrastructure decisions."
---

# KREW Hardware & Architecture Review Skill

## When to trigger

- Hardware procurement questions (switches, servers, UPS, storage, GPU)
- Network architecture decisions (VLANs, routing, firewall, NOS choice)
- Software stack decisions for self-hosted infrastructure
- "Should we use X or Y?" for any infrastructure component
- GEN4 rack planning questions (Høvik, Mellemveien 7)
- Security hardening questions for network or server infrastructure

## Primary reviewer: Sheldon (CTO)

Hardware and architecture reviews are owned by Sheldon (CTO, KREW-A002, Sonnet 4.6, 10K thinking). He leads. Bud (CFO) provides cost perspective. Andy's self-cost (NOK 3,500/hour) is always factored into maintenance burden calculations.

## GEN4 rack context (locked decisions — do NOT relitigate)

| Component | Decision | Status |
|-----------|----------|--------|
| Firewall/Router | pfSense on Netgate 7100 | LOCKED |
| Managed Switch | MikroTik CRS312 (RouterOS) | LOCKED |
| Server | HPE DL380 Gen10 | ARRIVED/IN TRANSIT |
| NAS | Synology RS1221+ | ARRIVED/IN TRANSIT |
| KVM | Avocent MPU4032 | ORDERED |
| OOB Console | Opengear ACM7004-5 | ORDERED |
| UPS | Ordered | IN TRANSIT |
| Sensor | AKCP SP2+ | OUTSTANDING |
| Rack | 27U Lanberg | BASEMENT |
| LLM Gateway | LiteLLM → Ollama + Anthropic | LOCKED |
| Cloud call cache | Vercel AI Gateway | LOCKED |
| No Redis | Redis removed from stack | PERMANENT |
| Monitoring | Grafana Cloud Pro ($19/month) | LOCKED |

VLAN design:
- VLAN 10: Management (switch UI, iLO, Opengear, AKCP)
- VLAN 20: Server/data
- VLAN 30: IoT (cameras, Axis PoE)
- VLAN 40: Office clients

MikroTik port security: **No MAC-based port security**. Use: disable unused ports, VLAN segmentation, DHCP snooping, BPDU guard.

## Review format

For any hardware or architecture decision, produce a Sheldon-led assessment:

```
## Architecture Review · [Component/Decision] · [date]

**SHELDON · CTO**
[Technical assessment: feasibility, compatibility with existing stack, security implications, 
maintenance burden at Andy's NOK 3,500/hour self-cost. Does it conflict with any locked decision?
2-4 sentences. Direct recommendation: use / don't use / use with these conditions.]

**BUD · CFO**
[Cost analysis: purchase cost, ongoing cost, TCO over 3 years. 
Compare to cloud alternative where relevant. 
2 sentences.]

**VERDICT**
✓ APPROVED / ✗ REJECTED / ⚠ APPROVED WITH CONDITIONS

CONDITIONS (if any):
- [Specific requirement before proceeding]

LOCKED: [What this decision locks in for future builds]
```

## Scoring dimensions

When comparing two options, score each on:

| Dimension | Weight | Description |
|-----------|--------|-------------|
| Compatibility | 30% | Works with pfSense/RouterOS/Ubuntu stack |
| Maintenance burden | 25% | Hours/month at NOK 3,500/hour |
| Cost (3-year TCO) | 20% | Purchase + ongoing |
| Security posture | 15% | CVE history, hardening complexity |
| Vendor risk | 10% | Single-source, EOL risk, support quality |

## Software stack (locked — GEN4)

```
OS:          Ubuntu 24.04 LTS (server)
Containers:  Docker Compose (30 services)
Firewall:    pfSense (Netgate 7100)
Switch:      RouterOS (MikroTik CRS312)
NAS:         Synology DSM (RS1221+)
NVR:         Frigate + Go2RTC
Automation:  Home Assistant
LLM local:   Ollama (GPU)
LLM cloud:   Anthropic API → LiteLLM
Gateway:     LiteLLM (bridges local + cloud)
Monitoring:  Grafana Cloud Pro
Alerts:      Prometheus rules → Grafana
```

## OOB recovery rule

**Always design for the Opengear.** Any configuration change that could lock Andy out of a device must have a documented serial console recovery path through the Opengear ACM7004-5. If a proposed change has no recovery path, do not approve it.

## Document output

Hardware decisions get logged to `qms_audit_log` (kind: `technology_decision`) and to the SAGA.WORX hardware document (SW-HW-001, currently at v1.2). Major decisions also get a chapter in the hardware manual. Reference the doc when advising on GEN4 build steps.

## Self-cost rule

When evaluating managed vs self-hosted:
- Self-hosted: add 2 hours/month minimum maintenance at NOK 3,500/hour = NOK 7,000/month hidden cost
- If the managed service costs less than NOK 7,000/month, managed wins on economics
- Example: Grafana Cloud Pro at $19/month (~NOK 200) vs self-hosted Grafana/Prometheus/Loki = managed wins decisively
