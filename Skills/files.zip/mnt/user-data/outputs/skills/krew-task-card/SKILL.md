---
name: krew-task-card
description: "Create a KREW agent task card whenever Andy says 'task for [agent]', 'task:', 'WO for', 'AO for', 'post a task card', or any instruction that assigns work to a named KREW agent. Always write to Supabase agent_tasks AND post to Slack. Do not acknowledge verbally before creating — execute immediately, confirm after."
---

# KREW Task Card Skill

## When to trigger

- "Task for [agent]:" followed by a description
- "WO for [agent]" / "AO for [agent]" / "SO:"
- "[Agent], please [action]" where the action is a concrete deliverable
- "Post a task card for [X]"
- Any instruction where a KREW agent is assigned work with an expected output

## Task types

| Type | Meaning | Who executes |
|------|---------|--------------|
| WO | Work Order | Human (Andy, Petter) |
| AO | AI Order / Agent Order | Named KREW agent |
| SO | System Order | Automated (Edge Function, pg_cron) |

## Three-phase pattern (KREW-OPS-018)

Every agent task exists in one of three phases:

- **prepare** — Agent does the work autonomously (T1). Default for all new AOs.
- **approve** — Chairman reviews output in Decision Queue (T2). Auto-created by `complete_agent_task()` when `approval_required=true`.
- **execute** — Agent acts on Chairman's approved decision (T1). Auto-created by `decide_agent_task()` when approved.

When creating a task card, assess whether the output will need Chairman approval before it takes effect. If yes, set `approval_required = true`.

## Supabase write (ccgsewlomcyikqpigofi)

```sql
INSERT INTO agent_tasks (
  title,           -- Full task title. Format: "[AGENT CODE]: [Task description]"
  description,     -- Context, objective, expected output. 2-5 sentences.
  agent,           -- Agent code: ceo | cto | cpo | cfo | cmo | clo | mitch | monica | alf | donna | carrie | bruce | jessica | edna | steve
  type,            -- 'wo' | 'ao' | 'so'
  status,          -- 'today' (urgent) | 'this-week' | 'next-week' | 'backlog'
  priority,        -- 'urgent' | 'high' | 'normal' | 'low'
  due_date,        -- ISO date or null
  approval_required, -- true if Chairman must approve before execution
  phase,           -- 'prepare' (default) | 'approve' | 'execute'
  proposed_by,     -- 'Chairman · [date]' or agent name
  workspace        -- 'krew' | 'sagaworx' | 'fore' | 'spotlight'
)
```

`ref` is auto-generated (WO-001, AO-002, etc.) — do not insert it manually.

## Slack post format

Channel: #proj-krew (C0B9QM6L4F5 if available) — fallback: #team-talx

```
*[TYPE]-[REF] · [AGENT NAME] · [PRIORITY]*
*[Task title]*

> [2-3 sentence description of the task, expected output, and context]

Owner: [Agent function title] · [Agent ID]
Due: [due date or "this week" or "backlog"]
Phase: [prepare / approve / execute]
Approval required: [Yes / No]
Proposed by: [Chairman / Agent]
```

## Agent roster quick reference

| Code | Name | Title | Model |
|------|------|-------|-------|
| ceo | Michael | Chief Executive Agent | Opus 4.8 |
| cto | Sheldon | Chief Technology Agent | Sonnet 4.6 |
| cpo | Amanda | Chief Product Agent | Sonnet 4.6 |
| cfo | Bud | Chief Financial Agent | Sonnet 4.6 |
| cmo | Don | Chief Marketing Agent | Sonnet 4.6 |
| clo | Louis | Chief Legal Agent | Opus 4.8 |
| mitch | Mitch | KREW Manager | Haiku 4.5 |
| monica | Monica | Quality Systems Agent | Haiku 4.5 |
| alf | ALF | Agent Learning Function | Sonnet 4.6 |
| donna | Donna | Personal Assistant Agent | Sonnet 4.6 |
| carrie | Carrie | Content Agent | Haiku 4.5 |
| bruce | Bruce | Business Development Agent | Haiku 4.5 |
| jessica | Jessica | Client Relations & Compliance Agent | Sonnet 4.6 |
| edna | Edna | Learning & Development Agent | Sonnet 4.6 |
| steve | Steve | UX Management Agent | Sonnet 4.6 |

## Priority scoring

Set priority based on due date and business impact:
- **urgent**: due today or overdue, or Chairman is blocked
- **high**: due this week, or another task depends on it
- **normal**: this sprint, no blocking dependency
- **low**: backlog, nice to have

## Multiple tasks in one message

Andy often embeds multiple task assignments in a single message. Capture ALL of them. Create separate Supabase rows and Slack posts for each. Do not combine into one card.

## Confirmation format

After creating:
```
Task created: [TYPE]-[REF] · [Agent] · [Title]
Supabase: ✓ agent_tasks
Slack: ✓ #proj-krew (or #team-talx)
Approval required: Yes/No
```
