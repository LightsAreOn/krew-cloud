---
name: krew-atopp
description: "Apply the Agent Task Output Persistence Protocol (KREW-OPS-018) whenever an agent completes a task, produces a deliverable, or Andy says 'done', 'log this', 'save output', 'mark complete', or 'close this task'. Always follows three steps in sequence: save output → log audit → trigger approval if needed. Never mark a task complete without completing all three steps."
---

# KREW Agent Task Output Persistence Protocol (ATOPP)
## KREW-OPS-018 · Ratified 17.06.2026

This protocol governs what happens when any KREW agent finishes a task. It is non-negotiable and applies to every task in every workspace.

## The three steps (always in this order)

### Step 1 — Save output to Supabase

If the agent produced a document, draft, analysis, or structured output:

```sql
-- Register the document
INSERT INTO qms_documents (title, series, num, status, owner, category, notes, revision, approved_by)
VALUES ('[Document title]', '[Series]', [num], 'DRAFT', '[agent_code]', '[category]', '[context]', '1.0', 'pending');

-- Save content to document files
INSERT INTO qms_document_files (doc_id, filename, mime_type, encoding, content_b64, bytes_original, version, sha256)
VALUES ([doc_id], '[filename]', 'text/html', 'base64', '[content]', [size], '1.0', 'pending');
```

If the output is too large for inline SQL (>50KB binary), store a `PENDING_UPLOAD` placeholder and create a CTO WO to upload via Claude Code.

For text summaries only (no document), skip document creation and write to `agent_tasks.result` directly.

### Step 2 — Call `complete_agent_task()`

This Supabase RPC handles closure logic atomically:

```javascript
const { data, error } = await window.db.rpc('complete_agent_task', {
  p_task_id: '[task UUID]',
  p_output_summary: '[2-3 sentence summary of what was produced]',
  p_output_doc_id: '[doc UUID or null]'
});
```

The function:
- Marks the task `status = 'done'`
- Writes result and output_doc_id
- Logs to qms_audit_log
- If `approval_required = true`: auto-creates an APPROVE task (AO type, phase=approve, assigned to chairman, due tomorrow, urgent)
- Returns `{ closed: uuid, approval_task_created: uuid, approval_task_ref: 'AO-XXX' }` or `{ closed: uuid, approval_required: false }`

### Step 3 — Notify

If `approval_required = true` and an approval task was created:
- Post to #proj-krew: "AO-XXX · Chairman approval requested · [task title] · Output ready for review in Decision Queue"
- The new AO task appears automatically in the Chairman's Decision Queue

If `approval_required = false`:
- Task is closed. Log a confirmation message only. No further action.

## Approval required — decision table

| Task type | Approval required? | Rationale |
|-----------|-------------------|-----------|
| Research / analysis / draft | No | Informational output, Chairman reviews if interested |
| Contract / legal document | Yes | Louis CLO output must be Chairman-approved before sending |
| Email to external party | Yes | Chairman approves before Donna sends |
| Code deployment | Yes | Sheldon CTO outputs staged; Chairman approves deployment |
| Financial commitment | Yes | Always Chairman-only, non-delegable |
| Internal process update | No | Monica/Mitch operational updates are self-closing |
| Blog post / content | No | Carrie + Don can publish; Chairman sees via brief |
| Agent evaluation result | No | ALF + Mitch loop is self-contained |

## The three-phase chain (reference)

```
PREPARE task → complete_agent_task() → 
  if approval_required=false: CLOSED
  if approval_required=true:  APPROVE task created →
    Chairman decides in Decision Queue →
      APPROVED: EXECUTE task created → complete_agent_task() → CLOSED
      REJECTED: REVISE task created → back to PREPARE
```

Each phase is a separate row in `agent_tasks` linked via `parent_task_id`. All three phases are visible in Work Management. The chain is fully auditable.

## Document series reference

| Series | Use |
|--------|-----|
| KREW-OPS | Operational procedures |
| KREW-HR | HR and agent onboarding |
| KREW-LGL | Legal documents |
| KREW-TECH | Technical documents |
| KREW-GOV | Governance and authority |
| KREW-PRD | Product requirements |
| SW-HW | SAGA.WORX hardware |
| AGENT-OUT | Auto-saved agent outputs |

## What NOT to do

- Never mark a task done in Supabase without calling `complete_agent_task()` — direct status updates bypass the approval chain.
- Never assume approval_required=false for legal, financial, or client-facing outputs.
- Never log output to `qms_audit_log` directly as a substitute for `qms_documents` — audit log is for events, not content.
