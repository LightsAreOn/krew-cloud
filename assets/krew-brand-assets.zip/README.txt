KREW BRAND ASSETS
=================

Logotype (wordmark + sphere, ~1174x407 px PNG):
  krew-logo-white-on-transparent.png   for dark or photographic backgrounds
  krew-logo-teal-on-dark.png           primary colorway
  krew-logo-white-on-teal.png          accent colorway
  krew-logo-teal-on-white.png          for light backgrounds

Logomark (standalone sphere, square PNG):
  krew-icon-1024-*.png                 social avatars, app icons
  krew-icon-512-teal-on-dark.png       smaller placements

Colors:
  Teal        #00FFB2   primary, on dark backgrounds
  Teal (dark) #00B27D   on white backgrounds
  Dark        #0A0A0A / #060A0F

Typography: IBM Plex Mono (wordmark, data), IBM Plex Sans (body).

Usage: wordmark always left, sphere always right. Please do not
recolor, stretch, rotate, or add effects. Questions and interview
requests: press@krew.cloud

The lights are on.
